class Constants {

  static final String appName = "Disease App";
  static final String newsScreenTitle = "News";
  static final String newsApiKey = 'd80ac280dd944371b8ab8561874230b3'; 

}